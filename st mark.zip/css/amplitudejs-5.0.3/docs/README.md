---
title: Overview - AmplitudeJS Documentation
meta:
  - name: description
    content: Amplitude.js is the HTML5 audio player for the modern era. Using no dependencies, take control of the browser and design a web audio player the way you want it to look.
  - name: og:locale
    content: en_US
  - name: og:type
    content: website
  - name: og:title
    content: Amplitude.js The Open Source HTML5 Audio Player for the Modern Era
  - name: og:description
    content: Amplitude.js is the open source HTML5 audio player for the modern era. Using no dependencies, take control of the browser and design an audio player the way you want it to look.
  - name: og:url
    content: https://521dimensions.com/open-source/amplitudejs/docs/
  - name: og:site_name
    content: Amplitude.js
  - name: og:image
    content: https://521dimensions.com/img/open-source/amplitudejs/og-image-amplitudejs.png
  - name: og:image:width
    content: 1200
  - name: og:image:height
    content: 630
  - name: twitter:card
    content: summary_large_image
  - name: twitter:description
    content: Amplitude.js is the open source HTML5 audio player for the modern era. Using no dependencies, take control of the browser and design an audio player the way you want it to look. Available for free on Github.
  - name: twitter:title
    content: Amplitude.js The HTML Audio Player for the Modern Era
  - name: twitter:site
    content: "@521dimensions"
  - name: twitter:image
    content: https://521dimensions.com/img/open-source/amplitudejs/og-image-amplitudejs.png
  - name: creator
    content: "@521dimensions"
---

# Overview
The concept of Amplitude.js is simple, allow designers to fully control the look
and feel of their audio player through the web without having to understand
advanced scripting. In HTML5, the audio tag allows users to add common audio
formats to their web page. The problem is that the audio playback interface is
controlled by the browser. Amplitude.js puts you in control of the design by
simply applying a class and/or attributes to page elements. You can then style these
elements through CSS and control your audio. Amplitude.js goes above and
beyond by adding playlist capabilities (next, previous, shuffle), song meta
data and visualizations. Amplitude.js is now mobile friendly as well. If it
detects a request coming from a mobile device it will apply a touchstart event
listener instead of a click to the appropriate elements.
